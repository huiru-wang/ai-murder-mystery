# 桑德伍德庄园的遗嘱

这是面向 AI Murder Mystery 平台的六人中文改编剧本包。它把原作的自由式 LARP 玩法收敛为固定凶手、两轮搜证、讨论、投票与揭晓的结构；角色私密信息、时间线和线索均为本次平台适配所重写。

## 来源与许可

- 改编自 Sondeirypt Games 的 *Of Magic and Murder*（2025）。原作页面：https://sondeirypt-games.itch.io/of-magic-and-murder
- 原作作者于 2026-05-05 将许可更新为 Creative Commons Attribution-ShareAlike 4.0 International（CC BY-SA 4.0）：https://sondeirypt-games.itch.io/of-magic-and-murder/devlog/1513831/updated-license
- 本衍生剧本亦以 **CC BY-SA 4.0** 提供。再次分享或改编时，请保留以上署名、原作链接、修改说明和同许可声明。

## 平台适配说明

- 固定为 6 名角色：凯西、亚历克斯、卡门、杰米、梅尔、里弗。
- 原作采用“幽灵主持人”、骰子、伤害和自由目标；这些机制未移植。平台版本使用当前引擎支持的讨论、地点搜证、投票和揭晓。
- 本包不包含原作 PDF、图像或道具卡；这些材料可在原作页面获取。
